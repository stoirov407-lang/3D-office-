# OFFICE — AI Company City

A polished frontend concept for the AI-company platform discussed in chat.

## Included
- City of virtual AI offices landing page
- White/glass 3D-office visual language
- Director + Discussion Room workflow
- Free agent creation/saving model
- Pricing: FREE, TRIAL, GO, PLUS, PRO, LUXURY
- Stripe-ready checkout UI (server integration placeholder)

## Stripe architecture
Use Stripe Billing + Stripe Checkout for recurring plans and a separate one-time Checkout Session for LUXURY.

Server routes to implement:
- `POST /api/create-checkout-session` — receives a plan key and creates a Checkout Session using a server-side Stripe secret key.
- `POST /api/create-portal-session` — creates a Stripe Customer Portal session.
- `POST /api/stripe/webhook` — listens for subscription/payment events and updates your database.

Store these server-side environment variables:
- `STRIPE_SECRET_KEY`
- `STRIPE_WEBHOOK_SECRET`
- `STRIPE_PRICE_GO`
- `STRIPE_PRICE_PLUS`
- `STRIPE_PRICE_PRO`
- `STRIPE_PRICE_LUXURY` (one-time Price)

Do not expose Stripe secret keys or Price creation logic in the browser.

## Product behavior
- FREE and base AI Director are available without payment.
- Agents can be created/saved without payment.
- Plans determine active-agent and office capacity.
- When a subscription ends, agents/tasks remain saved; agents above the active limit become inactive.
- On resubscription, eligible saved agents can be activated again.
